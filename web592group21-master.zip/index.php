<!DOCTYPE html>
<?php
 $appid = "kiklikchaken.appspot.com";
 $page = $_GET['p'];
 if($page=='') $page='index';
 $title = $page;
 function panel_include($title,$file,$ptype='default'){
echo "<div class='panel panel-$ptype'>";
echo "<div class='panel-heading'>$title</div>";
echo "<div class='panel-body'>";
if(file_exists($file)){
 include($file);
}else{
 echo "ไม่พบไฟล์ $file ";
}

echo "</div>";
echo "</div>";
 }
 
 use google\appengine\api\cloud_storage\CloudStorageTools;
function userpic($uid){
 global $appid;
 $userpic="gs://$appid/{$uid}.jpg";
 if(!file_exists($userpic)){
 return "user.png";
 }
 return CloudStorageTools::getImageServingUrl($userpic,["size"=>200]);
}

?>
<html lang="en">
<body role="document">
<button class="btn btn-small btn-inverse" type="button" ><?php panel_include("","index_user.php"); ?> </button>

</body>
</html>