<div id="navigation" class="navbar navbar-inverse navbar-fixed-top default" role="navigation">
  <div class="container">

    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
	 
   		<!--<div class="logo">
			<a href="main.php"><img src="images/logo2.jpg" alt=""/></a>-->
		</div>
    </div>
<a href="main.php "><img src="images/ss.png"></a>

	<div class="menu">
	     <ul class="megamenu skyblue">
		 <li class="active grid"><a class="color2" href="login1.php">login</a>
			<li class="active grid"><a class="color2" href="Shop.html">SHOP</a>
				
			</li>		
			
				<li class="active grid"><a class="color3" href="Sale.php">Sale</a></li>
				<li><a class="color7" href="register.php">News</a></li>
				<div class="clearfix"> </div>
			</ul>
			</div>
		
		
      </ul></nav>
    </div><!-- /.navbar-collapse -->
	</div>

  </div>
</div>